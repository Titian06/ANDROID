package com.example.taskmanager

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.taskmanager.R

class TaskAdapter(
    private val tasks: MutableList<Task>,
    private val onTaskCompleted: (Task) -> Unit,
    private val onTaskDeleted: (Task) -> Unit
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    // ViewHolder: Se encarga de mantener la referencia a las vistas
    class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewTaskTitle: TextView = itemView.findViewById(R.id.textViewTaskTitle)
        val imageViewDelete: ImageView = itemView.findViewById(R.id.imageViewDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_task, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = tasks[position]

        // Configurar el título de la tarea
        holder.textViewTaskTitle.text = task.title

        // Estilo de tarea completada (tachado) o pendiente
        holder.textViewTaskTitle.apply {
            paint.isStrikeThruText = task.isCompleted
        }

        // Marcar tarea como completada al hacer clic en el texto
        holder.textViewTaskTitle.setOnClickListener {
            task.isCompleted = !task.isCompleted
            onTaskCompleted(task) // Notificar el cambio al Activity
            notifyItemChanged(position)
        }

        // Eliminar tarea al hacer clic en el ícono de eliminar
        holder.imageViewDelete.setOnClickListener {
            onTaskDeleted(task) // Notificar al Activity que se elimine
        }
    }

    override fun getItemCount(): Int = tasks.size

    // Función para actualizar la lista después de eliminar una tarea
    fun deleteTask(task: Task) {
        val position = tasks.indexOf(task)
        tasks.remove(task)
        notifyItemRemoved(position)
    }
}
