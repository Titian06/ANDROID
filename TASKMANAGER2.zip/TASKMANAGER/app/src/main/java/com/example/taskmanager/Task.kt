package com.example.taskmanager

data class Task(
    val title: String,
    var isCompleted: Boolean = false
)
