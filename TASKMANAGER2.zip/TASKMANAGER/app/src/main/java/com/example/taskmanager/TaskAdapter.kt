package com.example.taskmanager

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TaskAdapter(
    private val tasks: List<Task>,
    private val onTaskClicked: (Task) -> Unit,
    private val onTaskDeleted: (Task) -> Unit
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    class TaskViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val textViewTaskTitle: TextView = view.findViewById(R.id.textViewTaskTitle)
        val imageViewDelete: ImageView = view.findViewById(R.id.imageViewDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_task, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = tasks[position]
        holder.textViewTaskTitle.text = task.title

        // Estilo para tareas completadas
        if (task.isCompleted) {
            holder.textViewTaskTitle.paintFlags =
                holder.textViewTaskTitle.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        } else {
            holder.textViewTaskTitle.paintFlags =
                holder.textViewTaskTitle.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
        }

        // Acciones de clic
        holder.textViewTaskTitle.setOnClickListener {
            onTaskClicked(task)
        }

        holder.imageViewDelete.setOnClickListener {
            onTaskDeleted(task)
        }
    }

    override fun getItemCount() = tasks.size
}
