package com.example.taskmanager

import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    // Lista para almacenar las tareas
    private val taskList = mutableListOf<Task>()
    private lateinit var taskAdapter: TaskAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Referencias a las vistas
        val editTextTask = findViewById<EditText>(R.id.editTextTask)
        val buttonAddTask = findViewById<MaterialButton>(R.id.buttonAddTask)
        val recyclerViewTasks = findViewById<RecyclerView>(R.id.recyclerViewTasks)

        // Configuración del RecyclerView
        taskAdapter = TaskAdapter(taskList,
            onTaskCompleted = { task ->  // Cambiado de `onTaskClicked` a `onTaskCompleted`
                task.isCompleted = !task.isCompleted
                taskAdapter.notifyDataSetChanged()
            },
            onTaskDeleted = { task ->
                val position = taskList.indexOf(task)
                taskList.remove(task)
                taskAdapter.notifyItemRemoved(position)  // Usar notifyItemRemoved para mejor rendimiento
            }
        )
        recyclerViewTasks.layoutManager = LinearLayoutManager(this)
        recyclerViewTasks.adapter = taskAdapter

        // Acción del botón "Agregar"
        buttonAddTask.setOnClickListener {
            val taskTitle = editTextTask.text.toString().trim()
            if (taskTitle.isNotEmpty()) {
                val newTask = Task(taskTitle)
                taskList.add(newTask)
                taskAdapter.notifyItemInserted(taskList.size - 1)  // Usar notifyItemInserted para agregar
                editTextTask.text.clear()
            } else {
                Toast.makeText(this, "Escribe una tarea", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

